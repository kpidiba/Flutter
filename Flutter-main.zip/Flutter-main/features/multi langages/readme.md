# INTERNATIONALIZATION

### DOCUMENTATION

https://docs.flutter.dev/accessibility-and-localization/internationalization



Best Tutorial

https://aditya-rohman.medium.com/how-to-provide-localizations-feature-to-a-flutter-app-with-bloc-library-shared-preferences-2c2f4fc2fb8a
