- go to https://www.appicon.co/

- decompresser et copier dans le dossier suivant

- android  go to android >main>res
