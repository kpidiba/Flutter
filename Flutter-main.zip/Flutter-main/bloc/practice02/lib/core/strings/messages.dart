// ignore: constant_identifier_names
const ADD_SUCCESS_MESSAGE = "Post Added Successfully";
// ignore: constant_identifier_names
const DELETE_SUCCESS_MESSAGE = "Post Deleted Successfully";
// ignore: constant_identifier_names
const UPDATE_SUCCESS_MESSAGE = "Post Updated Successfully";